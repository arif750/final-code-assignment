package com.rabbitmq.productconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductConsumerApplication.class, args);
	}

}
